package DragonFollow;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class DragonGame {
    //已经使用的成语总数
    public static long total = 0;

    // 开局随机生成一个成语
    public static String generateSartChengyu(ArrayList<String> arr,HashMap<String,Integer> hashMap)
    {
        if (arr == null || arr.size() == 0 || hashMap == null || hashMap.size() == 0)
            throw new NullPointerException("hashMap or arr数组存储的成语为空!");
        Random random = new Random();
        //随即返回一个成语
        String st = arr.get(random.nextInt(arr.size()));
        //设置成语已经使用标志
        hashMap.put(st,0);
        //已经使用的成语总数+1
        total++;
        return st;
    }
    //成语是否能连上
    public static boolean isDragonFollow(String one,String two) throws BadHanyuPinyinOutputFormatCombination {
        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        //设置不带音调
        format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        String[] oneArray = PinyinHelper.toHanyuPinyinStringArray(one.charAt(one.length()-1),format);
        String[] towArray = PinyinHelper.toHanyuPinyinStringArray(two.charAt(0),format);
        for (int i = 0; i < oneArray.length; i++) {
            for (int j = 0; j < towArray.length; j++) {
                if (oneArray[i].equals(towArray[j])){
                    return true;
                }
            }
        }
        return false;
    }

    // 输入用户的成语
    public static String inputUserChengYu(HashMap<String,Integer> hashMap,String systemCY) throws BadHanyuPinyinOutputFormatCombination, InterruptedException {
        //判断是否词库爆了
        if (total == hashMap.size())
        {
            //延迟5秒钟,模拟网络通信
            TimeUnit.SECONDS.sleep(5);
            System.out.println("成语词库资源耗尽,用户输入的成语无法匹配!游戏结束");
            System.exit(0);
        }
        Scanner scanner = new Scanner(System.in);
        System.out.print("请您输入您的成语:");
        String st = scanner.next();
        //控制用户最多输入的次数
        int count = 1;
        //检查是否使用过
        while (true)
        {
            count++;
            if (hashMap.get(st) != null && hashMap.get(st) == 1 && isDragonFollow(systemCY,st))
            {
                //设置成语已经使用标志
                hashMap.put(st,0);
                //成语已使用总数+1
                total++;
                break;
            }
            else if (hashMap.get(st) == null) {
                System.out.print("您的成语在数据库中不存在,请重新输入您的成语:");
                st = scanner.next();
            }
            else if (hashMap.get(st) == 0){
                //还要判断一下使用过的成语是否能匹配上
                if (!isDragonFollow(systemCY,st))
                    System.out.print("您的成语已经使用过了并且匹配失败,请重新输入您的成语:");
                else
                    System.out.print("尽管您的成语匹配成功,但是他已经被使用过了,请重新输入您的成语:");
                st = scanner.next();
            }else if (!isDragonFollow(systemCY,st)){
                System.out.print("成语不匹配,请重新输入您的成语:");
                st = scanner.next();
            }
            if (count == 3)
            {
                System.out.print("您的输入次数超过三次,系统判定您输了!");
                System.exit(0);
            }
        }

        return st;
    }

    // 输入系统的成语,返回null说明数据库爆了,或者没找到匹配的
    public static String inputSystemChengYu(HashMap<String,Integer> hashMap,String userCY,ArrayList<String> arr) throws BadHanyuPinyinOutputFormatCombination, InterruptedException {
        if (total == arr.size())
        {
            //延迟5秒钟,模拟网络通信
            TimeUnit.SECONDS.sleep(5);
            System.out.println("成语词库资源已经耗尽,无法生成新的成语!游戏结束");
            return null;
        }
        //遍历查找匹配的成语
        for (String s: arr) {
            if (isDragonFollow(userCY,s) && hashMap.get(s) == 1)
            {
                //设置成语已经使用标志
                hashMap.put(s,0);
                //成语已经使用得总数+1
                total++;
                return s;
            }
        }
        System.out.println("词库被你打爆了,你赢得了比赛!");
        return null;
    }
    //成语接龙游戏开始的主函数
    public static void startGame() throws BadHanyuPinyinOutputFormatCombination, InterruptedException, IOException {
        ReadList.deleteChongFu();
        ArrayList<String> arr = ReadList.getChengYu();
        HashMap<String,Integer> hashMap = ReadList.generateChengYuMap();
        //生成一个随机成语
        String systemCY = generateSartChengyu(arr,hashMap);
        String userCY;
        System.out.println("成语接龙开始了,小baby.....");
        System.out.println(systemCY);
        while (true)
        {
            //测试
//            System.out.println(hashMap);
            userCY = inputUserChengYu(hashMap,systemCY);
            systemCY = inputSystemChengYu(hashMap,userCY,arr);
            if (systemCY == null)
                System.exit(0);
            System.out.println(systemCY);
            //测试
//            System.out.println(hashMap);
        }
    }
}
