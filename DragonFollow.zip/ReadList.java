package DragonFollow;

import java.io.*;
import java.util.*;

/**
 * 把词典读入到列表中,和哈希表中
 */
public class ReadList {
    //对词典进行标号,1:未访问了,0:访问了
    public static HashMap<String,Integer> generateChengYuMap() throws IOException {
        HashMap<String ,Integer> hashMap = new HashMap<>();
        FileReader file = new FileReader("成语.txt");
        BufferedReader bufr = new BufferedReader(file);

        String content = null;
        //存储进入map中
        while ((content = bufr.readLine()) != null)
        {
            hashMap.put(content,1);
        }
        bufr.close();
        file.close();
        return hashMap;
    }

    //存储进入List
    public static ArrayList<String> getChengYu() throws IOException {
        ArrayList<String> arr = new ArrayList<>();
        //打开文件
        FileReader file = new FileReader("成语.txt");
        BufferedReader bufr = new BufferedReader(file);

        String content = null;
        while ((content = bufr.readLine()) != null)
        {
            arr.add(content);
        }
        bufr.close();
        file.close();
        return arr;
    }

    //去重,防止字典中有重复的成语
    public static void deleteChongFu() throws IOException {
        Set<String> set = new HashSet<>();
        FileReader file = new FileReader("成语.txt");
        BufferedReader bufr = new BufferedReader(file);

        //写入set中去除重复
        String content = null;
        while ((content = bufr.readLine()) != null)
            set.add(content);
        bufr.close();
        file.close();
        //把不重复的数据写回文件中
        FileWriter file1 = new FileWriter("成语.txt");
        BufferedWriter bufw = new BufferedWriter(file1);

        Iterator<String> it = set.iterator();
        while (it.hasNext())
        {
            bufw.write(it.next());
            //换行
            bufw.newLine();
        }
        //刷新进入文件中
        bufw.flush();
        bufw.close();
        file1.close();
    }
}
