package DragonFollow;

import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

import java.io.IOException;

/**
 * 成语接龙主函数:
 * 逻辑完整
 */
public class DragonMain {
    public static void main(String[] args) throws InterruptedException, IOException, BadHanyuPinyinOutputFormatCombination {
        DragonGame.startGame();
    }
}
